$(function(){console.clear()
  fn={
    dCode:function(a,b){//array,Δ=difference between two things
      for(I in Δ)a=a.replace(new RegExp(Δ[I],'g'),fn.l(Δ[I],b))
      return a},
    l:function(x,b){//times,σ=string,ι=iteration,l=length
      b=b||' '
      for(ι=σ='';ι<x;ι++)σ+=b+'0'
      return σ+b}}
  //example decoding string
  'Xmas_Elf2'
  'Xmas_Elf | |'
  'Frankie Halloween6Quartz Dark_Elf2Xmas_Elf2'
  'Frankie Halloween | | | | | | Quartz Dark_Elf | | Xmas_Elf | | '

  i=l='0'//Dragon
  D='Nature Firebird Mercury Gummy Lantern_Fish Tropical Zombie Petroleum Dandelion Jade '+
  'Star Terra Flaming_rock Armadillo Cloud Laser Mud Nenufar Hedgehog Icecube '+
  'Flame Neon Pearl Cool_Fire Medieval Penguin Ice 0 Carnivore_Plant Fluorescent '+
  '0 Electric Battery Sea5Metal '+
  'Dark Legendary Vampire Alpine Poo Vulcano Blizzard Rattlesnake Gold Soccer '+
  'Platinum Pirate Crystal Wind Mirror Coral Spicy Waterfall Cactus Storm '+
  'Ice_Cream Mojito Chameleon Hot_Metal Snowflake Seashell Moose Dragonfly Venom Steampunk '+
  'Dark_Fire Butterfly Robot Pure_Terra Pure_Flame Pure_Sea Pure_Nature Pure_Electric Pure_Ice Pure_Metal '+
  'Pure_Dark Pure Paladin Fossil Seahorse Sky Bat Aztec Chinese King '+
  'Wizard Two_headed Plankton Uncle_Sam Evil_Pumpkin Viking Jelly Quetzal Queen Thanksgiving '+

  'Santa Ghost Deep_Forest Ninja Ice&Fire Aurora Music Block Butterfly Alien '+
  'Great_White Pharaoh Paradise Gaudi Cool_Fire Octopus Jellyfish Carnival Love Dujur '+
  'T-Rex Brontosaurus Hydra Mars Prisma Centipede Emerald St_Patrick\'s Ruby Angry '+
  'Lava Joker Chainmail Sphynx Mummy Diamond Demon Gargoyle Deep_Red Blue '+
  'Archangel Lightning Ancient Wurm Light War Eternal Glacial Cerberus Burning '+
  'Treasure Granite Bone Wyvern Predator Poseidon Hades Atlas Justice Sun '+
  'Gaia Luminisicent Rainbow War Juggernaut Colossal Red_Woods Leviathan Panzer Nirobi '+
  'Droconos Monstruous Ivory Moon Toxic Obsidian Meteor Hammer Tribal Origami '+
  'Tiny Nightwind Thor Loki Odin Fallen_Angel Cold_Star Photon Elfic Zen '+
  'Tesla Kratus Saturn Dark_Stone White_Knight Black_Knight Thief Deus_Pet Midas Kryptonite_Dragon '+

  'Aquamarine Blue_Fire Hypno Stressed Troglodyte4Scrooge '+
  '0 Wrestler Clover 0 Poker Juggler 0 Speed Strong2Master 0 Chimera '+
  'Eclipse Specter 0 Crossfire Greenfluid Frozen_Wind '+
  '0 Aztec_Warrior Aztec_Priest Aztec_Emperor'+
  '26Chobby2Blind Cookie Elements Manglar Giant_Wings Amethyst Peace '+
  'Desert Heart 0 Twister Sylvan'+
  '7Cosmo Columbus Bavarian 0 Frankie Halloween Animation Joseon '+
  '0 Oni Hearts_Queen Big_Hat '+
  'Quartz Dark_Elf Sunset Snow_Man Xmas_Elf Necromancer '+
  'Middle_Earth Shogun Martial_Arts 0 Hawaiian Surf Ukulele Steam Howl Magnet '+
  'Quake Apocalypse Millenium Forge Promethium Abyss Mirage Supersonic Core Basilisk '+
  'Dolphin Easter Bookday Lightbeam Double_Terra Earth_Day Double_Nature Double_Flame Double_Electric Double_Ice '+
  'Double_Metal Double_Sea Mother\'s_Day 0 Space 0 Kaiju Acoustic Unity Anniversary '+
  '0 Cheshire_Cat Pterodactyl'+
  '7Zodiac_Taurus 0 Zodiac_Gemini Zodiac_Cancer Zodiac_Leo Zodiac_Virgo'+
  '6O_Rei Ney Pelusa Pulga Orange Inesta Ranoldo Zizou Father\'s_Day '+
  'Rapunzel Little_Red_Riding_Hood Adventure Cyborg Da_Vinci Korean_Soccer Independence_Day Genie 0 Sorcerer '+
  'Hellgate Albino Gold_Rush Apache Sheriff Mozart'+
  '4Scientific'+
  '6Sleeping_Beauty'

  //Description
  ds='The Nature Dragon loves humans, animals and all living things, some of them for gastronomic purposes. Even though never known to eat whole human being, a finger or two have been lost...+'+
  'Like Phoenix- the symbol of rebirth - this Dragon is said to be immortal. Its fire feathers and regal flight are an impressive sight. It is said that the birds\' cry is that of a beautiful song+'+
  'This Dragon is highly unpredictable, poisonous and has an exceptionally low melting point. But when the sun shines from the right angle, this liquid creature looks absolutely magnificent!+'+
  'Bouncy and happy, you will have a new best friend in this Dragon! The Gummy Dragon loves butterflies, sugar and summer clouds+'+
  'This mythical Dragon from the deepest oceans is an absolutely hilarious companion. The Lantern Fish Dragon can light up the darkest, stormiest night with its hilarious anecdotes from the life under water+'+
  'Tropical Dragon likes to dance all night, do acrobatics and enjoy life in general. Its happy-go-lucky attitude is very catchy, so in its company it is impossible not to smile!+'+
  'This undead Dragon has a huge appetite! It keeps eating, but somehow nothing seems to hold in. Despite its constant hunger, forgetful nature and bad vision it has proven to be loyal+'+
  'A Dragon of the darkest posture. It can look extremely dirty at first but is actually a very clean character. Petroleum Dragons like sunshine and sandy beaches and despise cold+'+
  'This feather light friend is a must for every Dragon enthusiast. Its puffy appearance will draw crowds from far far away to see its famous disappearing act+'+
  'The Jade Dragon is wisest of them all. Ask any question or present any problem and you will receive an answer from this ancient being. Now you\'ll just have to learn Chinese to understand him+'+

  'Who doesn\'t like looking at stars on a clear night? This Dragon is made of stars and during the nights you can see it shine. Star Dragon is one of the most calm and happy dragons, a friend to all+'+
  'Don\'t be alarmed, it\'s not an earthquake but a dignified Terra Dragon! Terra dragons are not known for their beauty, but for their love of dirt and their extremely humble and honest nature+'+
  'Flaming rock+'+
  'Armadillo is a slightly angry dragon, so be very careful when around it. It has heavy protective gear all over it, who knows what lies under all that armor and anger...Go and find it out!+'+
  'Many people don\'t even know that they have seen this Dragon because it perfectly blends into the sky. If you feel like the rain is sometimes following you, here you have the explanation!+'+
  'This futuristic dragon is a delightful addition to your islands. It\'s highly energetic and likes to fry small insects with its laser beams. This way you can also have bug control in your islands!+'+
  'Sometimes mistakenly described as chubby or lazy, but we happen to know that Mud Dragons are on a strict organic mud diet and they only enjoy an occasional fly when it happens to land directly on their mouth+'+
  'Fantastically beautiful, this dragon always draws crowds wherever it goes. Have you seen those floating flowers move in a pond? Maybe it wasn\'t a flower after all...+'+
  'This Dragon is extremely fond of people, but unfortunately its spiky exterior is not exactly human friendly. Wear an armor and go play!+'+
  'Is it getting hot in your Island? The Ice Cube Dragon is just the creature to cool things down. Calm, cool as ice and quite slow, this sympathetic fellow is no threat at all+'+

  'What happens when you set earth eternally on fire? This Dragon is one of the most energetic ones around. Flaming Rock especially loves Rock music and Dragon Chili snacks+'+
  'If you think neon colors were a thing of the ⑧ⓞ\'s, you are wrong! The neon colors are back. This Dragon is pure sunshine on wings!+'+
  'Pearl Dragon is known to be a bit vain and often wastes considerable amounts of time in shining its pearls. But when needed, it can be extremely brave and selfless and helps the ones in need+'+
  'If you thought northern lights are incredible, wait till you see this Dragon fly around in your islands! It\'s both as cool as ice and as hot as fire and it will never get tired of huffing and puffing+'+
  'The medieval Dragon hails from the times of King Arthur, who gave the dragon the precious task to protect his sword. Ever since he has been looking for a new master. Could it be you?+'+
  'At first sight it\'s easy to mistake this Dragon for a penguin. It\'s a common mistake but don\'t be fooled, its teeth are extremely sharp!+'+
  'With the recent climate changes, the super cool Ice Dragons have migrated to the North Pole. If you see one in a warm place, please direct them to the nearest ice rink and you\'ll have a friend forever+0+'+
  'This cheerful meat eater is almost blind but has an extraordinarily keen sense of smell. It can smell anything from miles away, so don\'t ever think that you can surprise this Dragon however hard you try+'+
  'This one glows in the dark, so it\'s highly convenient during the dark winter months. You will also save in electricity by getting this glowy Dragon!+'+

  '0+The tale tells us this dragon was born in a great storm that took place in the dark ages when an ordinary dragon got hit by a lightning. Since that day, you can see them on the skies, looking for a shock+'+
  'Running out of batteries all the time? This dragon will be your new best friend and you will always be charged with energy when around it!+'+
  'If you\'re into water sports, then the Sea Dragon will be your new best friend. Often Sea Dragons have been mistaken for seals or dolphins5'+
  'A robust dragon, drawn towards all things of metal. The word on the island is that what the Metallic Dragon lacks in intellect, it more than makes up in determination+'+

  'The Dark Dragon is highly elusive, only a handful of eye witnesses have managed to spot this creature of the night. Because of its color and nocturnal rhytm, it\'s virtually impossible to see it!+'+
  'This Dragon is so legendary that no words can do it justice. Be aware though: your life will never be the same again after encountering this creature made of legends+'+
  'When you have managed to catch the Vampire Dragon, you can truly congratulate yourself. Beware though that you can never quite tame it. Be very nice or it will fly!+'+
  'Alpine Dragon, the robust cousin of Ice Dragon is impossible not to love! This adorable creature is irresistibly playful and friendly. Watch out for avalanches though!+'+
  'Sometimes considered slightly disgusting, but in some parts of the world the Poo is known to bring good luck and fortunes for it\'s owner! Are you brave enough to take it to your island?+'+
  'This is the more explosive cousin of the Alpine Dragon. Always happy and cheerful, watch out though its hot!+'+
  'Weirdly enough this dragon made of snow and ice seems to like hot and wet environments! To see this rare dragon flap around in a pile of lava is definitely worth the effort!+'+
  'Potentially deadly, this Dragon has to be treated extra well to keep it from biting its master! When fully trained, it can be the most loyal servant+'+
  'Precious by nature, this Dragon is the most giving of them all. If you take good care and feed it well, it just might lay a beautiful golden egg+'+
  'The ancestors of this Dragon happened to make a home at a football stadium and that\'s how it all started. The Dragons started to watch the games and finally learned how to play themselves+'+

  'A Dragon of this magnitude certainly knows its worth. Platinum Dragon is generally known as the leader of the pack and isn\'t afraid to demonstrate its power+'+
  'A-hoy Dragon lovers! This very special Dragon will be a crown jewel in your Dragon collection. Get ready for some reckless sea adventures and hop on board!+'+
  'If you like shiny, valuable things, you will like the Crystal Dragon. It is very rare and only shows itself when the planets are appropriately aligned. You\'ll be lucky to see it! Breed Pure dragons to get the Legendary ones+'+
  'Famous for its flying skills, this Dragon can float for hours and hours without even moving a wing. It\'s a master of the currents and some witnesses say that it changes color according to weather! Breed Pure dragons to get the Legendary ones+'+
  'Do you like admiring yourself from the mirror? Then the Mirror Dragon will be your favorite buddy! Some people say that sometimes you can see a glimpse of the future from this dragon. Breed Pure dragons to get the Legendary ones+'+
  'Coral Dragon offers what is most beautiful under water. The colorful gardens of the abyss are more magnificent that you could ever imagine. This dragon is a treasure!+'+
  'Spice up your island kingdom with this temperamental fellow. The Spicy dragon is known for its excessive use of swearwords and a passion for Mexican food+'+
  'This dragon is an absolute wonder! Where does the water come from an where is it going? Who knows! It\'s still mesmerizing to watch+'+
  'Cactus Dragon loves to cuddle, what a shame that it is covered with spikes. If you\'re charmed by it despite the stings, put your gloves on and give it a hug!+'+
  'This dragon loves stormy weather more than anything! If you feel that living is getting too peaceful in your island kingdom, get the Storm Dragon to shake things up+'+

  'This dragon is so delicious that it\'s actually on the verge of extinction; greedy children everywhere tend to have a taste! Please refrain yourself and admire it from a distance+'+
  'You know that it\'s summer when you see mojitos everywhere! Invite this refreshing dragon into your islands and I can guarantee that the party never stops...+'+
  'A Master of camouflage - the Chameleon dragon actually changes color, so don\'t be alarmed if it seems to have disappeared, just wait a sec and it\'ll appear again! Fun fact: this dragon sees everything...+'+
  'The Hot Metal dragon is impressive - turn the temperature on and watch it ignite! This dragon comes from the core of earth, where its ancestors still live and breed+'+
  'This beautiful dragon is very friendly and delicate, always baring snowflakes - natures own works of art. Just keep the temperature low or it\'ll melt!+'+
  'Who doesn\'t love Seashells - the treasures of the sea? Offer this dragon a home and see what beautiful, shiny treasures will come out!+'+
  'Did you know that Moose is one of the most ancient animals around today? In the beginning of times in the ancient marshes, a moose and a dragon met... It was love at first sight and the result is delightful!+'+
  'Sometimes a dragon is even closer than you think - just sitting on the rock behind you of flying by when you\'re laying on the grass. Despite often being mistaken for an insect, the Dragonfly is all dragon+'+
  'Rising deep from the ground, comes the impressive Venom dragon. Potentially lethal but can also provide antidote when you most need it. Are you a risk taker?+'+
  'A masterpiece of classic machinery, this one actually came to life with a little help from our Dragon Master Deus. Keep it well oiled and you will have a loyal servant forever!+'+

  'From the darkest of caves rises a sombre character with eternal purple flames on its back with temperature unbearable to any other living thing. Whatever you do, don\'t show your fear+'+
  'Sometimes a dragon is even closer than you think - just sitting on the rock behind you of flying by when you\'re laying on the grass. Despite often being mistaken for an insect, the Dragonfly is all dragon+'+
  'Have you ever imagined your future with a robot servant? Well, the future is already here and this Robot Dragon is the best servant you can ever get! It even has a container for cold drinks+'+
  'Tougher, stonier and edgier, the Pure Terra Dragon is an impressive sight. It enjoys mountain climbing, rock crushing and pretty much all temperatures!+'+
  'This more mature dragon of the Flame element is royalty of dragons! As full of fire and character as the basic Flame dragon, but with twice the maturity and wisdom+'+
  'Even more watery than you could have ever imagined, this Pure Sea Dragon is also pure fun. Like a dolphin, always ready to play but very intelligent by nature+'+
  'Like a flower that just bloomed, this dragon is pure nature pleasure to watch. Everyone is always absolutely charmed by its beautiful energy and mesmerizing scent+'+
  'Electricity is strongly present in this dragon. If you touch it, you won\'t get electrocuted but cleansed and highly charged! With the Pure Electric you\'ll have a lot of energy for years to come+'+
  'Ice, Ice Baby! If you\'re not afraid of the cold then step into the Kingdom of Pure Ice where the temperature is so cold that the Ice turns into crystals. It\'s cold, shiny and beautiful here!+'+
  'This highly evolved Pure Metal Dragon consists of a mix of metals still unknown to man. It\'s incredibly durable and can take any heat without melting+'+

  'The darkness has now doubled! Two evil brains to plot some dark plans and four observing eyes to see even better in the twilight zone+'+
  'Can you imagine a creature so pure that it almost makes you blind with the light of its pureness? The Pure Dragon escapes our earthly words so you better experience it in person!+'+
  'The Paladin is a dragon made of epic adventures, noble deeds and magical powers. It\'s one of the most well behaving dragons of all time, but has a peculiar weakness for hot dogs!+'+
  'The unique quality of the Fossil dragon is that it can be trapped in Ice for centuries and yet fly away as agile as an eagle when the ice melts again. This dragon has a lot of stories to tell+'+
  'This happy-go-lucky dragon adores the beach life and sun! You can find it on all major surfing spots around the world, splashing in the waves and bringing smiles to the faces of all creatures+'+
  'This dragon is as mysterious as it gets! It\'s a whisper in the air, a light breeze on your cheek on a September day, the slightest shadow disappearing before your eyes... Catch it if you can!+'+
  'Deriving from bats, this dragon has many special talents. It is an amazingly agile flyer and can eat up to 1OOO orcs per hour. Adopt it to keep your neighborhood clean!+'+
  'Coming from deep in the jungle, where it\'s mysterious civilization has dwelled unmolested for millenia, this rare dragon\'s wisdom is sought after by sages far and wide+'+
  'This dragon has always been close to the emperor of China and some even say that it might be the true holder of the imperial power. It brings you good luck, prosperity and wisdom+'+
  'Contrary to popular belief, the king dragon often leaves the throne and mingles with low-birth dragons, willing to share the joys of a life away from wealth, if only for a while+'+

  'Most would think that combining a wizard and a dragon would result in pure magic. Unfortunately this dragon is mostly known for its clumsiness and utterly strange sense of humor+'+
  'Two is definitely better than one! This two headed beast is double the fun and double the trouble! Please don\'t turn your back on it unless you want to end up as the target of a practical joke+'+
  'Comfortable both under and above water, this dragon is known as the \'wanderer\' - able to travel thousands of miles without a rest. With its magnificent glow, it\'s especially impressive at night+'+
  'This dragon is all stars, stripes and bangles and it wants YOU to enjoy Dragon City with your friends! He\'s very sporty, social and has always been the most popular dragon of the Island+'+
  'Carved pumpkins are cute, but watch out for this one - it\'s pure evil in an orange package! It\'ll steal your candy and egg your car before you have time to say "Boo"!+'+
  'Watch out for this nordic dragon, it\'ll do everything possible to conquer and pillage the habitats of other dragons... unless it decides to sleep and enjoy a lengthy meal instead!+'+
  'Wobbly and cheerful, this dragon is a blast! It has a special ability to change color when it grows up and make people of all ages laugh hysterically!+'+
  'Dating back from the mesoamerican jungles, this dragon is a boundary maker between heaven and earth. Moving fast to the skies and back, Quetzal is also the high priest of all Dragons!+'+
  'The prettier counterpart of the power couple -Their Majesties King and the Queen Dragon- is known for her peaceful and fair nature. Only the tricks of the evil witch will awake her dark fury!+'+
  'This dragon is one of the first habitants of the magical Dragon Islands! It\'s known for it\'s humble and grateful nature and has an incredible fondness towards oven cooked turkey!+'+

  'Ho ho ho! The merriest dragon ever wishes you an awesome Christmas! With him all the days of the year are filled with peace and sharing+'+
  'Are you ready to be haunted? This ghastly dragon possesses a slightly split personality, so you will never know if it\'s evil or good when you play with it+'+
  'From the depths of forests that were old when Mankind was young this dragon comes, herald of an age long forgotten. Pay respect since this dragon is the guardian of all forest creatures!+'+
  'Keep your eyes on this dragon at all times, since despite its cute look, it\'s extremely dangerous and crafty! Turn around and you just might have a ninja star in your back...+'+
  'This creature of extreme controversy is very hard to capture! Its life is a constant migration from the equator to the antarctic to keep both sides satisfied+'+
  'This dragon is even harder to spot than the northern lights themselves and hence not much is known about its nature. Just get ready for the most amazing show that this planet has to offer!+'+
  'Can your hear that mesmerizing sound coming from above? It\'s the Music Dragon, creating the most beautiful sounds with its wings while flying through the clouds of Dragon Islands...+'+
  'What happens when plastic, electricity and dark forces combine? A Block dragon is created - the dragon with a great sense of humor and an infinite collection of slightly naughty jokes!+'+
  'Sometimes a dragon is even closer than you think - just sitting on the rock behind you of flying by when you\'re laying on the grass. Despite often being mistaken for an insect, the Dragonfly is all dragon+'+
  'It\'s a dragon from another universe, a completely unindentified and an alien entity! Don\'t even try to fool this creature, it can read your mind before you even think your thoughts!+'+

  'This dragon is legendary even amongst the legendary dragons. Its regal stature attracts attention wherever it flies. It prefers colder climates due to the risk of sunburns+'+
  'When the sun sets behind the ancient pyramids, some statues start to move...This ruler dragon can be still as a statue for centuries before taking a tour in the darkness of the night+'+
  'What happens when you put a dragon to paradise? It grows bright, light feathers, starts to glow like gold and is filled with eternal peace and tranquility unlike any other dragon known+'+
  'This is an Unreleased Dragon. But you can see it in Tournament (Stadium)+'+
  'If you thought northern lights are incredible, wait till you see this Dragon fly around in your islands! It\'s both as cool as ice and as hot as fire and it will never get tired of huffing and puffing+'+
  'This dragon is the boss of all the pirates and can fight up to ⑧ opponents at the same time with its evil tentacles! Beat it and you can be very proud of your achievement+'+
  'Sometimes the most beautiful thing can be the most harmful. Looking at the Jellyfish dragon might feel like a mesmerizing dream, until you get too close...+'+
  'There\'s no party like a Carnival Dragon party! Wherever this dragon travels, the party starts immediately. If you can\'t handle the fun, stay out of the way!+'+
  'Will love unite us or tear us apart? For those searching answers for some big questions, getting to know this endearing dragon is highly recommended! All you need is Love Dragon+'+
  'Despite its size, Dujur is as light as a spring cloud and hence does not need wings for flying. Dujur brings good luck with it wherever it flies and never gets tired of helping children!+'+

  'The T-Rex dragon still greatly resembles one of the most dangerous hunters ever. Something changed along the way though since this specimen is one of the most harmless dragons around+'+
  'This vegetarian giant loves all living creatures: children, animals, dragons... But most of all it loves all plants suitable for eating! In fact there are rumors that \'bronto\' means \'forever hungry\'+'+
  'The legend tells that when you cut one of Hydra\'s heads off, two more will grow in its place. So you better keep this dragon with a poisonous breath on your friendly side!+'+
  'Get ready for some serious x-files action with this stranger-than-fiction dragon. Remember to feed it with plenty of space plasma and dragon food to avoid baby dragons disappearing...+'+
  'What really happens at the end of a rainbow? From the reflections of the shiny treasures, a Prisma dragon is born with all the colors of the universe on its back+'+
  'This dragon is one of the fastest dragons...on land! It can break dance like a pro but in the air it often gets tangled up in its own feet and wings and completely loses control+'+
  'Not all that shines is gold... Some of it is emerald! This extremely precious dragon is one of the most valuable ones in Dragon Islands. Guard it to make sure it doesn\'t get stolen+'+
  'On St. Patrick\'s day, everyone\'s Irish! And being Irish on this day means a non-stop celebration with green colors. Befriend this buddy if you wanna party all year long!+'+
  'If you wanna capture the light of million sunsets, the glimmer of thousand lakes and the heat from the hottest fires, get the Ruby dragon and visitors will flock to your islands!+'+
  'Don´t make this Dragon get angry! It may look a little bit absent minded and cute, but there are secret powers hidden in its mutant blood...+'+

  'During the last million of years, this super mighty Dragon has been sleeping in the deepest cracks of the mountains. Now it´s time to unleash its power!+'+
  'Time to laugh! This very rare Dragon loves pranks and tricks. If you give him the chance, you´ll find a sticker on your back saying "kick me!"+'+
  'This unique armored Dragon will be one of the most precious pieces of your collection. As powerful as Armadillo, and as stunning as Platinum, the Chainmail Dragon is a magical masterpiece+'+
  'Ra blessed this magical creature gazillion of years ago. Mysteries and mystical powers are hidden in the Pyramids guarded by the Sphynx+'+
  'Many think that the Mummy Dragon was formerly a Zombie Dragon with some concerns about his look, but that´s not true. Mummy Dragon was long ago a king among kings, and now he´s back...+'+
  'Star dust, the most solid rock in the universe and Deus´ magical touch made this Dragon become alive. Rumors say that not even the Emerald and Ruby Dragons combined could defeat this new juggernaut+'+
  'The realm of dragons has it\'s own mystique side. It is said that the Demon Dragon appears on the nightmares of the other dragons+'+
  'Daylight turns him into a stone statue, but at night he awakens! Look closely at the black sky and you might find him roaming the darkness above you+'+
  'This is an Unreleased Dragon. But you can see it in Tournament (Stadium)+'+
  'Deep in the sea and close to the volcanic faults, the Blue Dragon emerged centuries ago as the King of the dephts. Are you bold enough to tame him?+'+

  'Deus himself created the Archangel Dragon when he was a brave young god. When he needs something done, he chooses the Archangel Dragon for the job+'+
  'Have you ever heard the quote \'There´s always calm before the storm\'? Ancients say that this quote refers to the Lightning Dragon+'+
  'for eons, there was nothing but time and ... the Ancinet Dragon! Even if this sounds kind of boring, this gives the Ancient Dragon! an unique perspective about basically everything+'+
  'Be carefull what you wish, there is always a chance that the Wurm Dragon appears and acomplishes it. Maybe not exactly as you thought it+'+
  'Deus himself created the Archangel Dragon when he was a brave young god. When he needs something done, he chooses the Archangel Dragon for the job+'+
  'Every empire in history has feared the huge War Dragon. It destroys everything in its way, including buildings, bridges, other dragons... and its enemies\' morale+'+
  'This is an Unreleased Dragon. But you can see it in Tournament (Stadium)+'+
  'The razor-sharp edges turn the Glacial Dragon\'s whole body into a dangerous weapon! In the cold season he retreats back in the polar regions to regenerate his powers+'+
  'Also known as The Guardian, the Cerberus Dragon protects the dungeons and the treasures inside them. He has a lot of spare time during his guards so he enjoys playing Rock \'n\' Roll+'+
  'The fire inside the Burning dragons is not usual fire. It\'s a magic dark fire with the power to consume anything in seconds, much quicker than the usual and of course way more dangerous+'+

  'Jewels, gold, magic crystals, diamonds... the Treasure Dragon hoards the riches of his defeated enemies in his lair. Only a dragon master can control the Treasure Dragon. Is that you?+'+
  'It is said that Granite Dragon combines the three hardest rock types on earth. Let\'s not enter into science details, this just means it is three times tougher+'+
  'This soulless dragon comes from the northern lands, far beyond the wall. He is controlled by dark magic that Darkus created millenia ago, providing his dead body with powerful attacks+'+
  'Deus sends the Angel Demon as his agent when he needs something. Using his divine powers he obeys his master, usually for good+'+
  'This dragon loves herbivores, especially to eat them. Be careful! When he\'s hungry he begins to devour any living thing slower than him. Except kittens+'+
  'Poseidon is usually quite calm and sleepy, living under the sea. If he gets angry however, he starts producing tsunamies and earthquakes. Fun fact: He hates eating fish+'+
  'The realm of the underworld is controlled by Hades. He actually became friends with the sea of souls, which he considers a lot of fun. It\'s his most favourite part of this job+'+
  'Atlas is usually exhausted from carrying the globe from one side to the other. That duty has shaped his body, resulting in a powerful dragon able to perform the most impressive attacks!+'+
  'If you feel an injustice happened, just call the Justice Dragon. His balance will decide what’s fair... and it’s sword will decide what’s not+'+
  'The Sun Dragon lives inside the solar corona. When there\'s a sun storm, you can see it dancing with the flares, just like a child splashing in a swimming pool+'+

  'Gaia Dragon is known as the mother of all plant dragons. It has a gentle nature until it gets angry, just like all the mothers+'+
  'Deep into the sea looks pretty dark. The luminiscent has evolved into total darkness providing his own light, which uses for hunt and disco parties, two things totally mergeable+'+
  'This is an Unreleased Dragon. But you can see it in Tournament (Stadium)+'+
  'Every empire in history has feared the huge War Dragon. It destroys everything in its way, including buildings, bridges, other dragons... and its enemies\' morale+'+
  'War has an interesting background. It has been in every possible battle since the beginning of time, and it still wants more! Every scratch it has on its body corresponds to another dragon\'s defeated in battle. Or maybe from its pet kitten!+'+
  'It is hard not to be impressed by the size of this dragon. From far away it looks big. As it gets closer it becomes huge. And when you see it close up, it\'s totally colossal+'+
  'The Red Woods contain the tallest trees and the tallest dragons. They are made of millenary wood, making them extremely resistant but prone to boredom - especially when they yawn for an entire month+'+
  'This epic creature has inhabited the seas for eons, devouring entire civilization as a snack. Do you dare go deep and discover the treasures it hides?+'+
  'This is an Unreleased Dragon. But you can see it in Tournament (Stadium)+'+
  'Master of doom and darkness. Lord of all he creepy things. His LinkedIn profile is totally impressive if you\'re looking for an expert in the bad side of things. Breed Pure dragons to get the Legendary ones+'+

  'Time is relative, everybody knows that. What most people don\'t know is that Droconos plays with time as a child plays with a ball. Déjà-vus are his favourite jokes. Breed Pure dragons to get the Legendary ones+'+
  'This classy monster comes from another dimension, a world full of Monster Legends! He crossed space and time to join the Dragon City inhabitants, where he feels really welcome+'+
  'This majestic dragon is the envy of all dragons. His skin is shiny white ivory with filigrees of gold. It\'s as though an artist had made a beautiful dragon sculpture, and it had come to life!+'+
  'Have you ever seen a full moon? It happens once ever twenty eight days. That is exactly the sleep period of the Moon Dragon which wakes up really angry and usually gets back to bed+'+
  'Be careful! It\'s toxic! This dragon has a strange diet. He loves to have some sulfur for breakfast and radioactive remains for lunch, altought he is on a diet now so he only gets a couple of old batteries for dinner+'+
  'After a volcano explodes Obsidian is the material that remains! Hard, Cutting, this dragon is pure Power! Every single edge he has is a deadly knive!+'+
  'Millenia ago, the Meteor Dragon got in a fight with the Brontosaurus Dragon. He flew up in the sky and hit the earth at a high speed, causing the extinction of all the dinosaurs on the earth+'+
  'Do you know why this dragon is called Hammer Dragon? Some people think it is because he looks like the hammer fish, but actually he just likes to hit things with his metal head - mainly other dragons+'+
  'Ukma akma atma utma, entu entu aku aku!!! This is actually the war cry of the Tribal Dragon, which means "attack"!+'+
  'When Deus was a child, he liked the art of Origami. One day he created a beautiful paper dragon, and he blew life into it. Since then, the Origami Dragon can be seen floating on thermal air currents high in the sky+'+

  'Even in mature adulthood, this dragon remains tiny. For this reason, this little dragon appeals to many girls! But don\'t be fooled. Despite its small size, this dragon is seriously tough opponent+'+
  'In the darkest nights the Nightwind dragon howls to the sky like a wolf. Your heart will freeze if you hear him!+'+
  'Thor is known for his mastery at war, besides his beloved six pack. He loves to battle since he can remember, making every fight a competition against his brother, Loki+'+
  'Loki has always been a clever and sharp warrior. With his deadly dark skills he\'s able to defeat most of his enemies. There is only one thing he lacks to be a perfect warrior: His brother\'s hammer!+'+
  'Deus and Odin often hang out together. When so, they talk about exciting topics as the weather or new born dragons. When they get extremely bored by that stuff, they start dragon wars. Betting on their best champions, they watch the fight together+'+
  'The Northern Myths tell us that this dragon was punished by Deus, who took away his Angel status and condemned him to a life on Earth. But within two days he was having lots of fun in his new land, hanging out with Visigoths+'+
  'Born in cold outter space, this dragon\'s diet consists of White Dwarf stars and tomatoes, thats why he travels around galaxies. Cold Star Dragon is the most spaced out of them all+'+
  'This quantic dragon is the guardian of the electromagnetic forces! It couldn\'t be faster than light because it\'s pure light, all colors of the light spectrum emanates from its inside+'+
  'Since the first time the Elves walked over Arda this dragon has been protecting them all. His armor is made of leather strips, iron ingot and refined moonstones. And he is immune to all the forces of evil+'+
  'Six arms! Two to stand on the ground in homage to the First Noble Truth, "all life is suffering." Two for meditation, "to avoid craving and aversion." And two more to follow the Noble ⑧-Fold Path and develop compassion for others+'+

  'The Master of War and Electricity. Lord of the Bolts and Strikes. Commander of Energy and Conflict. And Father of Modern Battle Science. His curriculum is fairly impressive+'+
  'Full of rage and anger, Kratus is the last of his kind. He is known as the Dragon of War. Feared, respected and also admired by all, no one dares to face him in battle+'+
  'There is no doubt that the Saturn Dragon comes from outer space. The beauty of his wings can hypnotize you if you look at them for more than one second! Finding one of these celestial dragons on Earth is a rather rare occurrence!+'+
  'Like volcanic rock he\'s extra lightweight so he is able to fly with those small wings at sound speed. Those thick arms and horns seems to deals super damage but being so porous his punches are harmless+'+
  'The White Knight Dragon was created with love and light magic. His pureness make him a beloved dragon, always protecting the good and justice from the Black Knight Dragon, who insists in fighting him again and again and again...+'+
  'The Black Knight Dragon was created from hate and black magic. His warrior abilities are famous, as it is his sword \'Stormbroker\'. For some reason, his only fate in life is to fight the White Knight Dragon, again and again and again...+'+
  'Everyone is innocent until proven guilty, except the Thief Dragon! Using tricks and traps gets all he wants. Do not turn your back on him but if it\'s gold what you want this is your dragon!+'+
  'Everybody knows Deus loves Dragons! But as always happens, he has a favourite. The chosen one is the Deus Pet Dragon, probably because it is one of the cutest dragons ever created+'+
  'This Dragon conceded the Golden Touch to King Midas. Midas could convert all he wanted into gold and became the richest king ever. But that blessing became a curse when he accidentally converted his own son into gold. Get Midas Dragon and drown between mountains of gold!+'+
  'It\'s a bird? It\'s a plane? Oh wait.. it\'s nothing because the Kryptonite dragon has just eaten it! Attention, superheroes of the world, the Kryptonite dragon has come!+'+

  'This dragon likes to live near water. He gets his name from his color, a shade of transparent green and blue. He likes to camouflage himself in the water when he is hunting fish. Aquamarine is a very agile and graceful dragon!+'+
  'Some kids dream with strange creatures while sleeping. That\'s the case of the Blue Fire Dragon, which cames from a kid\'s dream straight into Dragon City!+'+
  'A realTrickster! The Hypno Dragon can make you blindly believe you\'re a chicken or a frog! Spinning his spiral eyes he hypnotizes all who resist his will. You better be his friend. But wait, he has no friends! You better run!+'+
  'The craziest dragon in Dragon City! You may wonder if his hairstyle is natural –and the answer is yes! Do you like it? Well, just don\'t ask him how he does it, because you need to be really stressed out to have such crazy hair!+'+
  'This dragon is also known as a cave dweller. He likes to live in caves or beneath overhanging rocks of cliffs. If you give him a tinder and flint, he will make a perfect, cozy fire in a few minutes!4'+
  'Scrooge Dragon might seem a bit cold-hearted at first. And indeed he is. But he is also a financial genius! If he includes you in his will, you\'ll never want for gold, gems or tomatoes again+'+

  '0+Are you ready to get this Dragon into the battle arena? His thousands of fans will be watching him and expecting him to win, because he is the star! He is the one and only, the unique, the amazing, the invincible Wrestler Dragon!+'+
  'One, two, three, four ... five-leaf clover! Assured and confident this dragon never fails. You could say that was born under a lucky star. Other dragons feel luckier when they\'re close to Clover Dragon. Will you be luckier when you get him?+0+'+
  'He holds all the cards. Or is he bluffing? Sometimes in life you have to take risks, but it\'s best not to when you\'re playing with the Poker Dragon. In Las Vegas, he\'s the boss+'+
  'This dragon is an amazing performer. His tricks and talent are beyond anything you have seen so far. Be careful as well as he is one cunning adversary+0+'+
  'Speed Dragon is, as you may guess, the fastest dragon in Dragon City! He\'s never late when meeting friends and likes to run wherever he goes. You can always find him training at the track and field! Beep beep!+'+
  'Strong Dragon was born in a gym… So it\'s not difficult to understand his passion for exercise. You don\'t want to make him angry, for he can reduce you to ashes with his claws!2'+

  'This dragon is truly a master when it comes to control the elements. It attacks are mystical and also it masterful nature. Be careful when training as it\'s already a master in disguise+0+'+
  'A dragon wrought of the immortal flame! Lion-fronted with the body of a snake, he has goat\'s horns and he breathes a terrible flame of bright fire. Watch your enemies tremble at the sight of the Chimera Dragon+'+
  'The sun hides when the Eclipse Dragon rises. Old civilizations knew about this mythic dragon and could predict his appearances. When they knew he was coming, they would prepare themselves to UV④ⓞⓞ sunglasses to enjoy the show!+'+
  'Some dragons enjoy living in shadows and darkness. This is the case of the Specter Dragon. When he gets bored he likes to scare other dragons, which makes him quite unpopular with his peers+0+'+
  'The main attractive of this dragon are the magic tatoos of his body. Each tatoo grants the dragon a different power. The mix of all of them makes him a hard opponent to fight!+'+
  'This amazing green fluid dragon was created from the magical goo of dragonstone. It has great powers and can change from solid to fluid in no time+'+
  'If you suddenly notice goosebumps on your arms and your nose goes cold, it could be that the Frozen Wind Dragon is near! Ignore this message if you notice these symptoms when opening your fridge+'+

  '0+Hiding deep in the jungle, this amazing warrior can wait days and days, until his prey is defenseless. Then when he strikes, one single blow is usually enough for him to defeat his enemy+'+
  'The stars hold no secrets for the Aztec Priest Dragon. His knowledge of the Universe is as famous as his amazing cape, made from real dragon skin+'+
  'He comands armies of thousands. His people love him. He has dominated and won dozens of wars. It\'s understandable that after all this stress, he has relaxed a little. And maybe gotten a little bit chubby'+

  '26'+

  'Don\'t bother telling Chobby Dragon he\'s cool. He knows he is! It\'s like "The Emperor\'s New Clothes" - if you can\'t see his coolness, it\'s because you\'re dumb!'+
  '2Sometimes what it looks like a weakness it is actually a strenght! The Blind Dragon has developed amazing hearing and smelling skills, making him unique for spinache and mushrooms finding!+'+
  'Crunchy and sweet, the Cookie Dragon breeds perfectly with the Milk Dragon. Wait! Does Milk Dragon even exist? Who knows, but what we know for sure is that Santa brings bigger presents to Cookie Dragon Masters!+'+
  'This dragon is the perfection itself! It\'s elements are combined in such a way that no one is more important that other, making a hard to find balance of all of them+'+
  'This dragon likes to live in the rainforest. When he wants, it\'s almost impossible to see him because he can camouflage himself to blend in with nature. Manglar Dragon is peaceful and strong as an ox!+'+
  'Some dragons have tiny wings, some others have big wings and a few have giant wings! That\'s the case of the Giant Wings Dragon, that can fly higher than any other dragon!+'+
  'One of the most beautiful dragons on the world, she is the sister of the Quartz Dragon. As you can imagine, their skin is pretty tough as it is made of mineral, nothing to do with her hearth which is lovely soft+'+
  'The Peace Dragon spreads love and peace all over Dragon City. Be careful though, if you are not peaceful enough you will suffer the consequences!+'+

  'Desert Dragon comes from the most arid place in the world and is accustomed to high temperatures. He is so big because he stores so much water under his rocky skin! This allows him to survive many weeks without drinking!+'+
  'Heart Dragon is pure tenderness, soft and sweet. He will give you back all the love you give him and then some. If you hug him, you won\'t be able to let him go+0+'+
  'Six wings for a sea dragon may seem too much, but you\'ll soon see why when he surfaces! Just by twisting his body this awesome dragon can create the most destructive whirlwinds and tornadoes. Don\'t get too close...+'+
  'Sylvan dragons are the guardians that keep dark shadows from the elven woods. They are born and raised in the deeper parts of the forest where they are trained to be a light force of nature'+

  '7Raise your head and look to the sky on a clear night to watch the incredible Cosmo Dragon fly. Created by star dust and earth sand, his skin reminds to the night and his wings to the universe greatness+'+
  'Dragonpher Columbus is well known for discovering the flying islands in ①⑨④②. All the dragons you own live on the islands he discovered!+'+
  'Lift up your stein and give a loud \'Prost\!\' for the Bavarian Dragon. He and all the other dragons are enjoying some pretzels and later they\'re going to dance on the tables+0+'+
  'Did Doctor Frank really put together different dragon parts to create a dragon? It does look quite scary! When it\'s dark the Frankie Dragon sneaks around and scares other dragons+'+
  'The master of pranks is the Halloween Dragon. Whenever he throws his head in the air, you can hear some shocked screams. He enjoys this a lot!+'+
  'It\'s been a while since dragons evolved from frozen frames and began to walk, fly and fight! And it\'s all thanks to the animation wizards and magae! Animation Dragon was the first of its kind. Thats why he is so special and loved by everyone+'+
  'Rising up from Korea the Joseon dragon comes back to fight. Blast your enemies with the power of water and fire! Stand strong against attacks with the element of metal. The Joseon dragon is unleased to the world!+0+'+

  'This Oni Dragon may have been a fearsome demon long ago but he discovered the power of QI and in his attempt to become the strongest demon he became peaceful and wise. He might not look like an ogre, but watch out, he can eat you in one bite!+'+
  'It is far better to be feared than loved. That\'s what the Hearts Queen Dragon says. She may not be the best for breeding but you should try her in battle! Sentence first! Verdict afterwards. Off with their heads!+'+
  'It\'s tea time! Time to switch seats! This energetic dragon can seem a little crazy at first - that\'s why he is also known as the Mad Hatter! With him your tea parties will totally rock+'+
  'Quartz is the element that the ancient druids used in their armors and rituals. It was the Quartz Dragon who taught the ancient celtic civilization the special characteristics of this rock+'+
  'The Dark Elf Dragon slips from the shadows of night to slay his enemies. He is silent as an elephant and as persistent as a snake... or was it the other way around?+'+
  'The best time to see this dragon is at sunset. Some people confuse him with a giant bat or vampire dragon because of his wings and the way he looks. It is said that he can block the sun with his giant wings and his majestic appearance+'+
  'Snowmen are one of the loveliest things you\'ll see at Christmas. But a Snowman Dragon is simply irresistible! Be careful not to hug him too or he could melt!+'+
  'Santa\'s best employee, this dragon is the manager of all elves. Known for handing out candies to children, Xmas Elf Dragon is the Most Wanted this season. You will find him by the sound of the bell that hangs from its tail+'+
  'The Necromancer Dragon likes to communicate with the deceased, summoning their spirits or raising their bodies from the dead. He uses the deceased as a source for hidden knowledge or as weapons. Rumor has it that he uses black magic to fuel his powerful spells, which makes him a truly frightening enemy+'+

  'Small size but big hearted this little dragon carry the fate of us all. He may seem a traveller but on the way to fulfill his fate he will became a hero! All that is gold does not glitter, don\'t judge by appearances because even the smallest dragon can change the course of the future+'+
  'This Japanese commander has the power of 100 dragons but his main virtue is his calm mind in the battlefield. Victory is the only result he knows and to keep his honor he will perform arakiri with no hesitation!+'+
  'A master in Ansatsuken, always improving, no matter the difficulty, no matter the cost. He can\'t avoid fighting for innocents when he sees injustice. He is the only one who dominates the Hadoken technique+0+'+
  'This dragon has great rhythm, stunning moves and always feels the groove. These are perfect qualities for this fun and festive dragon. He\'s the first to arrive at any Hawaiian party!+'+
  'If you don\'t see this dragon at first, you probably need to get atop some tall waves. Keep your eyes peeled. When he rides a surf board, it\'s art in motion!+'+
  'This dragon has got the rhythm! Once he starts playing his ukulele, the groove spreads to all other dragons, and they start dancing with him. His good vibes are contagious!+'+
  'This unique dragon is pure boiler pressure! With his rare combination of elements, he developed his own element – Steam! This inexhaustible energy source will meet all your needs+'+
  'After being bitten by a werewolf, this creature became a hybrid of beast and dragon. While the Howl Dragon\'s element is Dark, he is also connected to Nature and Energy Elements+'+
  'Nowadays, the power of magnetism is no secret for us and we know it is the most powerful force on earth.  Breeding this dragon will be as difficult as getting two positive poles together!+'+

  'Some earthquakes are caused by tectonic plates - others occur when a Quake Dragon lands. This sudden release of seismic power can destroy towns and cities; thank God you are on a flying island!+'+
  'The most powerful of the four-elements-dragons, he spells the end of an era! With his combination of four opposite elements, the Apocalypse Dragon is pure destruction – albeit unintentionally. He is so difficult to breed that you may never see one+'+
  'The most ancient of all four-elements-dragons can finally be yours! Within the Millennium Dragon lurks the infinite power of time. The rare combination of its elements makes it unique and matchless+'+
  'The most incandescent of all four-elements-dragons is the one that inhabits the center of the earth. Flying between lava flows, the Forge Dragon is in charge of keeping the planet\'s core molten+'+
  'The most unpredictable of all four-elements-dragons. He is the lord of quantum mechanics; its body is pure energy, so he can control all the matter surrounding him. Don\'t get too close, it\'s radioctive!+'+
  'The most unknown of all four-elements-dragons. He combines the most antagonistic pairs of elements. Coming from the deep unknown, he is the master of light and darkness, fire and ice. Expect the unexpected!+'+
  'The most delusive of all four-elements-dragons. For years, Mirage Dragon was considered a myth - a fabrication of a few crazed Dragon Masters. Today we know he is real, but that doesn\'t mean he\'s easy to breed!+'+
  'The fastest of all four-elements-dragons, Supersonic Dragon is difficult to attain He flies ten times the speed of sound and strikes before anybody hears him coming. You better build a pretty nice habitat or he will leave before you even see him+'+
  'Core dragon is one of the space dragons. He is in charge of creating new planets. As a Dragon Master, you\'d be pleased to have him in your city+'+
  'This dragon is a descendant of the great Basilisk from an age long forgotten. He has all the traits and wits of his ancestors, but has developed some new abilities, too+'+

  'From the Socialpoint Fan Art contest comes the Dolphin Dragon! It\'s said that these animals are social, but this particular one prefers a like to a sardine!+'+
  'This funny little dragon is here to bring colored eggs and candy to all good little dragons. Is so cute and so sweet ... But don\'t lick him! This one is not made of chocolate!+'+
  'Shakespeare, Cervantes and countless writers are connected with this date.  St. George\'s Day where roses and books are exchanced between sweethearts.  Have a nice day!+'+
  'Such a beautiful thing! This mystic and noble dragon is one of the rarest of its kind. You can not touch him since he is just a light illusion. He will fill your breeding cave with pure essence+'+
  'Don\'t be alarmed, it\'s not an earthquake but a dignified Terra Dragon! Terra dragons are not known for their beauty, but for their love of dirt and their extremely humble and honest nature+'+
  'This dragon only appears once a year during Earth Day! A what an amazing sight for sour eyes. Be sure to catch him on that special day+'+
  'The Nature Dragon loves humans, animals and all living things, some of them for gastronomic purposes. Even though never known to eat whole human being, a finger or two have been lost...+'+
  'If you can\'t take the heat, stay away from the Flame Dragon! This temperamental creature is easily set off, but calms down equally fast and always feels deep remorse for the things it burned+'+
  'The tale tells us this dragon was born in a great storm that took place in the dark ages when an ordinary dragon got hit by a lightning. Since that day, you can see them on the skies, looking for a shock+'+
  'With the recent climate changes, the super cool Ice Dragons have migrated to the North Pole. If you see one in a warm place, please direct them to the nearest ice rink and you\'ll have a friend forever+'+

  'A robust dragon, drawn towards all things of metal. The word on the island is that what the Metallic Dragon lacks in intellect, it more than makes up in determination+'+
  'If you\'re into water sports, then the Sea Dragon will be your new best friend. Often Sea Dragons have been mistaken for seals or dolphins+'+
  'This dragon has an unconditional love for their children. She is loving and warm so their grateful children returns the affection on this special day. Happy mother\'s day!+0+'+
  'Time is relative, specially for this ancient dragon. He was born with the big bang at the oldest part of the universe. Since then he has been travelling between galaxies creating new planets+0+'+
  'This horrifying Kaiju Dragon was first seen in ①⑨⑤④. It\'s said that he was born out of the atomic explosions, but he love tomatoes, too. Some people know him as the King of the Monsters!+'+
  'This rare shaped dragon has the special ability to redirect the soundwaves at his will! That may not seem super useful but that allows him to know all secrets and gossips from Dragon city+'+
  'This elegant space dragon is the guardian of balance. He leads his fellow dragons, but he\'s not a leader. An integral part the cosmos, he ensures that all universal forces flow in a common direction+'+
  'Two Years we have been together... It\'s time to celebrate! But, what a surprice! Inside the cake we baked together with Cookie Dragon a new dragon has been found! Anniversary dragon is here with all your jokes and pranks+'+

  '0+The Cheshire Cat Dragon loves to appear and disappear at will! This dragon sometimes raises philosophical points to annoy or baffle other inhabitants of Dragon City+'+
  'The scariest dragon from the Jurassic period has come to join his fellows. You may be afraid of his teeth and spikes but be aware of his claws, that you can split into two'+

  '7Taurus is one of the Zodiac Dragons that give their names to our constellations. This dragon is known as The Heavenly Bull. He is full of positive energy and he best serves those around him+0+'+
  'Gemini is one of the Zodiac Dragons who give their names to our constellations. This dragon is associated with the twins Castor and Pollux of Greek mythology. It is said that Gemini Dragon is the protector of sailors+'+
  'Cancer is one of the Zodiac Dragons who give their names to our constellations. This dragon is associated with the crab Karkynos of Greek mithology. It is said that Cancer is very respected and feared, for he fought with Hercules in ancient times+'+
  'Leo is one of the Zodiac Dragons who give their names to our constellations. This dragon is a descendant of the Nemean Lion who liked to take hostages to its lair in a cave. You better watch out!+'+
  'Virgo is one of the Zodiac Dragons that give their names to our constellations. This dragon is associated with agriculture and holds the scales of justice in his hands. Wherever he is, food and happiness abound'+

  '6This dragon is know as O Rei, as you can see on his crown. Wherever he plays soccer, he is praised and respected by other dragons+'+
  'This dragon is considered the heir of O Rei Dragon. Don\'t be fooled by his young appareance, his electrifying movements are difficult to see, and he can beat his oponents in the blink of an eye!+'+
  'Pelusa is frequently mistaken for his brother, Zeus, because of his Godly qualities. He is adored and revered by the other dragons in Dragon CIty for his mastery of the soccer ball+'+
  'Pulga Dragon is considered the heir to Maradano Dragon. It is said that his mastery of the soccer ball is even greater, and this generates lots of debate in the dragon society. It is said that he is somehow linked to Zeus...+'+
  'Orange Dragon is known for his technical ability, speed, acceleration and dribbling, but his greatest quality is vision. He is able to detect and predict the movements of his opponents, which makes him a fearsome adversary!+'+
  'Known by everyone as one of the calmest and most elegant dragons. A hero and example to many dragons, he is respected and admired everywhere he goes. Don\'t irritate him, for he can defeat you before you have time to react!+'+
  'Ranoldo Dragon is as fast as lightning and has the power and strength of ten thousand bulls. You best not mess around with him if you don\'t want to make him angry, in which case it would be the end of you+'+
  'Despite his physical appearance, Zizou Dragon is one of the most elegant and intelligent dragons in Dragon City. He is very diplomatic with everyone, but he won\'t hesitate to use force if necessary+'+
  'This dragon loves his children unconditionally and protects them. He is loving and warm, so his grateful children return the affection on this special day. Happy Father\'s Day!+'+

  'Rapunzel Dragon is one of the most beautiful creatures in Dragon City. Her long blond hair dazzles all who look at her hair. You\'ll fall in love with her!+'+
  'This dragon loves to go for long walks in the forest and through the woods to bring food to her sick grandmother. If one day you happen find her in the countryside walking around, you can ask her for a piece of the delicious food she carries in her basket!+'+
  'This is probably one of the most adventurous dragons in Dragon City! He is always hunting ancient treasures, solving mysteries and breaking curses. You\'ll never get bored of him!+'+
  'Sent from the future, this cyborg has come to Dragon City to serve and protect it from villains. Half dragon, half machine, he has mighty strength+'+
  'One of the most talented creatures in Dragon City, Da Vinci Dragon is an architect, sculptor, engineer, inventor and painter who delights the inhabitants with his works of art+'+
  'Once upon a time, the ancestors of this Dragon happened to make a football stadium their home. The Dragons started watching the games and finally learned how to play themselves.That\'s how it all started+'+
  'Happy Independence Day! This ancient dragon was born on the ④th of July, ①⑦⑦⑥, and helped the Americans in their fight for independence with his courage and determination. He is the most patriotic dragon in Dragon City+'+
  'From the ②nd Social Point Fan Art contest comes the Genie Dragon! It is said these creatures can grant three wishes! Choose wisely and make your dreams come true!+0+'+
  'This dragon is one of a few remaining sorcerers, hunters for hire gifted with supernatural powers. Despite his appearance, he always protects and defends the helpless, even if his methods are sometimes considered politically incorrect+'+

  'Straight out of Hell, this dragon is feared by all the rest. When he appears, it means death and a disaster are soon to follow. Rarely sighted, it is said that he feeds on the souls of the innocent+'+
  'Albino Dragon is a rare dragon in Dragon City. He\'s the only dragon with no skin color, and when he\'s angry he shines so bright he can blind his enemies. When this happens, he doesn\'t waste the chance to give them what they deserve+'+
  'This dragon is a tireless seeker, a hard worker who won\'t stop until he finds what is most precious to him. Gold fever is running through his veins!+'+
  'A friend of peace. Fearless and honorable. Apache dragon might seem like a unfriendly warrior at first, but he follows a code of honor, which makes him memorable and a valuable ally+'+
  'This dragon is always looking out for the welfare of others. Defender of the helpless, this tireless avenger always has troublemakers in his sights+'+
  'His musical notes sweeten the ear of everyone in Dragon City. A master like no other with a gift that makes him unique in its kind'+

  '4With a super high IQ, Scientific Dragon dedicates his life to researching and solving the everyday problems of all dragons. It\'s a lot harder than it looks!'+

  '6Sleeping Beauty Dragon is one of the most beautiful dragons in the kingdom. Many dragons fight to win her heart, but she remains pure in the hope of finding the dragon that awakened her from her dream+'

  Δ='26 12 7 6 5 4 3 2'.split(' ')//points indexing remaining gaps
  D=fn.dCode(D).split(' ')//ok, let's finish array; 'a b c' to ['a','b','c']
  ds=fn.dCode(ds,'+').split('+')//I'd tried to let splitter know with \n but that didn't work so, I've used + instead
  !D[D.length-1]&&(D.pop()) //retire last position cause that's empty
  !ds[ds.length-1]&&(ds.pop())

  for(i in D)$('<div title="'+ds[i]+'"><img src=img/'+((dr=D[i])==='0'?'none':i==113||i==142||i==146||i==355?'no':i)+'.jpg><label>'+(/_/.test(dr)?dr.replace('_',' '):dr)+'</label><label>'+(1000+Number(i))+'</label></div>').appendTo('.D')
  $('.D>div').mouseenter(
    function(){
      $(t).css({
        left:((this.offsetLeft+5)+'px'),
        top:((this.offsetTop+5)+'px')})})})
